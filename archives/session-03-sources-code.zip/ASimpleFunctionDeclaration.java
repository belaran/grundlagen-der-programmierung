
public class ASimpleFunctionDeclaration {

	/**
	 * Adds the two integer values provided and return the 
	 * results. 
	 * 
	 * @param firstArg, an integer value
	 * @param secondArg, an integer value
	 * @return the sum of both parameter
	 */
	public int add(int firstArg, int secondArg) {			
		return firstArg + secondArg;
	}
}



