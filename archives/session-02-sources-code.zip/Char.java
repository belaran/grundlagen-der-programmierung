/**
 * 
 * Probably one of the most powerfull piece of program I ever wrote... No, really ! 
 * 
 * @author Romain PELISSE
 *
 */
public class Char {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		char a = 'a';
		char b = 'b';
		a / b;
		System.out.println("Result:" + a + b );
	}
}
