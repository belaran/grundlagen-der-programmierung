/**
 * @author Romain PELISSE - belaran@gmail.com
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("HelloWorld !");
	}
}
