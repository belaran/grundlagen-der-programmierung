/**
 * @author Romain PELISSE - belaran@gmail.com
 *
 */

public class Steuerzahler {

	double id;
	short taxClass;
	long lastYearRevenue;
	// ...
}
